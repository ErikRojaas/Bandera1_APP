package com.bandera1.Engine.GameObjects;

import java.util.ArrayList;
import java.util.List;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.bandera1.Engine.Systems.SceneSystem;

public class Scene {
    public List<GameObject> gameObjects;

    public Scene() {
        gameObjects = new ArrayList<>();
    }

    public Scene(List<GameObject> gameObjects) {
        this.gameObjects = gameObjects;
    }

    public void render(SpriteBatch batch) {
        for (GameObject gameObject : gameObjects) {
            if (!gameObject.enabled) continue;
            gameObject.render(batch);
        }
    }

    public void addGameObject(GameObject gameObject) {
        if (gameObjects.contains(gameObject)) return;
        gameObjects.add(gameObject);
        if (SceneSystem.activeScene == null) {
            SceneSystem.newGameObjects.add(gameObject);
        }
    }

    public void removeGameObject(GameObject gameObject) {
        gameObjects.remove(gameObject);
    }

    public void update() {
        List<GameObject> objects = new ArrayList<>(this.gameObjects);
        //filter enabled objects
        objects.removeIf(gameObject -> !gameObject.enabled);
        for (GameObject gameObject : objects) {
            for (Component component : gameObject.components) {
                component.update();
            }
        }
    }

    public void dispose() {
        for (GameObject gameObject : gameObjects) {
            for (Component component : gameObject.components) {
                component.dispose();
            }
        }
    }

}