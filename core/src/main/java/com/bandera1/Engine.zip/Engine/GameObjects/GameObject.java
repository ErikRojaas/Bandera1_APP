package com.bandera1.Engine.GameObjects;

import java.util.List;
import java.util.UUID;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Intersector;

import com.bandera1.Engine.Systems.SceneSystem;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class GameObject implements Serializable {
    public String name;
    public UUID id;
    public boolean enabled;
    public Transform transform;
    public List<Component> components;

    public GameObject(String name) {
        this.name = name;
        id = UUID.randomUUID();
        enabled = true;
        components = new ArrayList<>();
        transform = new Transform();
        components.add(transform);
    }

    public final void render(SpriteBatch batch) {
        for (Component component : components) {
            if (component.enabled) {
                component.render(batch);
            }
        }
    }

    public final void dispose() {
        for (Component component : components) {
            component.dispose();
        }
    }

    public final <T extends Component> T getComponent(Class<T> componentClass) {
        for (Component component : components) {
            if (componentClass.isInstance(component)) {
                return componentClass.cast(component);
            }
        }
        return null;
    }

    public final void addComponent(Component component) {
        components.add(component);
        component.gameObject = this;
        component.init();
    }

    public final void removeComponent(Component component) {
        components.remove(component);
        component.gameObject = null;
    }

    public final void show() {
        enabled = true;
    }

    public final void hide() {
        enabled = false;
    }

    private GameObject deepClone() {
        try {
            // Serialize the object to a byte array
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(bos);
            out.writeObject(this);
            out.flush();
            byte[] byteData = bos.toByteArray();

            // Deserialize the byte array to a new object
            ByteArrayInputStream bis = new ByteArrayInputStream(byteData);
            ObjectInputStream in = new ObjectInputStream(bis);
            return (GameObject) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error cloning object, make sure that all fields of components implement Serializable interface");
            e.printStackTrace();
            return null;
        }
    }

    private static void alterCloneName(GameObject clone) {
       //get a number from the name if it has one
       int number = 0;
       String name = clone.name;
       if (name.contains("#")) {
           number = Integer.parseInt(name.substring(name.indexOf("#") + 1));
           String prefix = name.substring(0, name.indexOf("#"));
           clone.name = prefix + "#" + number+1;
       } else {
           clone.name += "#1";
       }
    }

    public static GameObject instantiate(GameObject gameObject, Vector2 position, float rotation) {
        GameObject clone = gameObject.deepClone();
        clone.id = UUID.randomUUID(); 
        clone.transform.position = position;
        clone.transform.rotation = rotation;
        for (Component component : clone.components) {
            component.gameObject = clone;
            component.init();
        }
        SceneSystem.activeScene.addGameObject(clone);
        alterCloneName(clone);
        return clone;
    }

    public static GameObject instantiate(GameObject gameObject, float rotation) {
        GameObject clone = gameObject.deepClone();
        clone.id = UUID.randomUUID(); 
        clone.transform.rotation = rotation;
        for (Component component : clone.components) {
            component.gameObject = clone;
            component.init();
        }
        SceneSystem.activeScene.addGameObject(clone);
        alterCloneName(clone);
        return clone;
    }

    public static GameObject instantiate(GameObject gameObject, Vector2 position) {
        GameObject clone = gameObject.deepClone();
        clone.id = UUID.randomUUID(); 
        clone.transform.position = position;
        for (Component component : clone.components) {
            component.gameObject = clone;
            component.init();
        }
        SceneSystem.activeScene.addGameObject(clone);
        alterCloneName(clone);
        return clone;
    }

    public static GameObject instantiate(GameObject gameObject) {
        GameObject clone = gameObject.deepClone();
        clone.id = UUID.randomUUID(); 
        for (Component component : clone.components) {
            component.gameObject = clone;
            component.init();
        }
        SceneSystem.activeScene.addGameObject(clone);
        alterCloneName(clone);
        return clone;
    }

    public static GameObject Find(String name) {
        for (GameObject gameObject : SceneSystem.activeScene.gameObjects) {
            if (gameObject.name.equals(name)) {
                return gameObject;
            }
        }
        return null;
    }

    public static void Destroy(GameObject gameObject) {
        SceneSystem.activeScene.removeGameObject(gameObject);
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id.toString();
    }
    
}

